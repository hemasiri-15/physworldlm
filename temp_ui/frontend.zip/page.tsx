"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import PromptEditor from "@/components/PromptEditor";
import PromptSuggestions from "@/components/PromptSuggestions";
import WorldPreview from "@/components/WorldPreview";
import Footer from "@/components/Footer";

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [hasResult, setHasResult] = useState(false);

  const handleGenerate = () => {
    if (!prompt.trim() || isGenerating) return;
    setHasResult(false);
    setIsGenerating(true);
    // Placeholder timing until the pipeline is wired to a backend.
    window.setTimeout(() => {
      setIsGenerating(false);
      setHasResult(true);
    }, 2200);
  };

  return (
    <main className="min-h-screen bg-[#09090b]">
      <Navbar />
      <Hero />

      <section className="relative mx-auto max-w-7xl px-6 pb-24 lg:px-8">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-3"
          >
            <PromptEditor
              value={prompt}
              onChange={setPrompt}
              onGenerate={handleGenerate}
              isGenerating={isGenerating}
            />
            <PromptSuggestions onSelect={setPrompt} />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-2"
          >
            <div className="lg:sticky lg:top-24 lg:h-[560px]">
              <WorldPreview isGenerating={isGenerating} hasResult={hasResult} />
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
